import React from 'react';

const MyBuyers = () => {
    return (
        <div>

        </div>
    );
};

export default MyBuyers;